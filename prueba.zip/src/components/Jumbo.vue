<template>

  <v-card elevation="4" class="pa-4" rounded="lg">
    <v-img class="jumbo" src="../assets/jumbo.jpg"></v-img>
    <h2 class="py-4">Bienvenido</h2>
    <p>Bienvenido al sistema de ordenes e inventario de ClassicModels</p>
  </v-card>

</template>

<script>
export default {};
</script>

<style lang="sass">
.jumbo
  height: 350px
</style>